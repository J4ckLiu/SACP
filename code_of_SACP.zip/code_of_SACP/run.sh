python main.py --model sstn --data_name ip --alpha 0.05 --base_score APS
